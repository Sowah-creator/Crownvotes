import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import db from './db.js';

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'development-only-change-this-secret';
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin: process.env.APP_BASE_URL || true}));
app.use(express.json({limit:'1mb'}));
app.use(express.static('public'));
app.use('/api', rateLimit({windowMs: 15*60*1000, limit: 300}));
const authLimit = rateLimit({windowMs:15*60*1000, limit:12, message:{error:'Too many attempts. Try again later.'}});
const tokenFor = u => jwt.sign({id:u.id, role:u.role, email:u.email}, JWT_SECRET, {expiresIn:'12h'});
function auth(req,res,next){try{const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):'';req.user=jwt.verify(token,JWT_SECRET);next();}catch{return res.status(401).json({error:'Please sign in.'});}}
function admin(req,res,next){if(req.user?.role!=='admin')return res.status(403).json({error:'Administrator access required.'});next();}
const slugify = s => s.toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');

app.get('/api/health',(_,res)=>res.json({ok:true,app:'CrownVotes'}));
app.post('/api/auth/register',authLimit,(req,res)=>{
  const schema=z.object({name:z.string().min(2).max(80),email:z.string().email(),password:z.string().min(10).max(100)});
  const p=schema.safeParse(req.body); if(!p.success)return res.status(400).json({error:'Enter a valid name, email and password of at least 10 characters.'});
  try{const info=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(p.data.name,p.data.email.toLowerCase(),bcrypt.hashSync(p.data.password,12));const u=db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(info.lastInsertRowid);res.status(201).json({token:tokenFor(u),user:u});}catch{return res.status(409).json({error:'An account with that email already exists.'});}
});
app.post('/api/auth/login',authLimit,(req,res)=>{
  const p=z.object({email:z.string().email(),password:z.string().min(1)}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Enter your email and password.'});
  const u=db.prepare('SELECT * FROM users WHERE email=?').get(p.data.email.toLowerCase());if(!u||!bcrypt.compareSync(p.data.password,u.password_hash))return res.status(401).json({error:'Incorrect email or password.'});
  res.json({token:tokenFor(u),user:{id:u.id,name:u.name,email:u.email,role:u.role}});
});
app.get('/api/me',auth,(req,res)=>res.json(db.prepare('SELECT id,name,email,role,created_at FROM users WHERE id=?').get(req.user.id)));
app.get('/api/events',(_,res)=>res.json(db.prepare("SELECT e.*, (SELECT COUNT(*) FROM categories c WHERE c.event_id=e.id) category_count FROM events e WHERE status='published' ORDER BY created_at DESC").all()));
app.get('/api/events/:slug',(req,res)=>{const e=db.prepare("SELECT * FROM events WHERE slug=? AND status='published'").get(req.params.slug);if(!e)return res.status(404).json({error:'Award event not found.'});const categories=db.prepare('SELECT * FROM categories WHERE event_id=?').all(e.id).map(c=>({...c,nominees:db.prepare('SELECT id,name,bio,image_url,vote_count FROM nominees WHERE category_id=? ORDER BY name').all(c.id)}));res.json({...e,categories});});
app.get('/api/admin/overview',auth,admin,(_,res)=>res.json({users:db.prepare('SELECT COUNT(*) n FROM users').get().n,events:db.prepare('SELECT COUNT(*) n FROM events').get().n,votes:db.prepare('SELECT COALESCE(SUM(quantity),0) n FROM votes').get().n,revenue:db.prepare("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE status='paid'").get().n}));
app.post('/api/admin/events',auth,admin,(req,res)=>{const p=z.object({title:z.string().min(3).max(120),description:z.string().max(2000).optional(),starts_at:z.string().optional(),ends_at:z.string().optional(),vote_price:z.number().int().min(1).max(100000),status:z.enum(['draft','published']).default('draft')}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Check the event details and vote price.'});let slug=slugify(p.data.title);if(db.prepare('SELECT id FROM events WHERE slug=?').get(slug))slug+=`-${Date.now()}`;const x=db.prepare('INSERT INTO events(title,slug,description,starts_at,ends_at,vote_price,status) VALUES(?,?,?,?,?,?,?)').run(p.data.title,slug,p.data.description||'',p.data.starts_at||null,p.data.ends_at||null,p.data.vote_price,p.data.status);res.status(201).json(db.prepare('SELECT * FROM events WHERE id=?').get(x.lastInsertRowid));});
app.post('/api/admin/events/:id/categories',auth,admin,(req,res)=>{const p=z.object({name:z.string().min(2).max(100),description:z.string().max(500).optional()}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Enter a category name.'});const e=db.prepare('SELECT id FROM events WHERE id=?').get(req.params.id);if(!e)return res.status(404).json({error:'Event not found.'});const x=db.prepare('INSERT INTO categories(event_id,name,description) VALUES(?,?,?)').run(e.id,p.data.name,p.data.description||'');res.status(201).json(db.prepare('SELECT * FROM categories WHERE id=?').get(x.lastInsertRowid));});
app.post('/api/admin/categories/:id/nominees',auth,admin,(req,res)=>{const p=z.object({name:z.string().min(2).max(100),bio:z.string().max(1000).optional(),image_url:z.string().url().optional().or(z.literal(''))}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Check nominee details and image URL.'});const c=db.prepare('SELECT id FROM categories WHERE id=?').get(req.params.id);if(!c)return res.status(404).json({error:'Category not found.'});const x=db.prepare('INSERT INTO nominees(category_id,name,bio,image_url) VALUES(?,?,?,?)').run(c.id,p.data.name,p.data.bio||'',p.data.image_url||'');res.status(201).json(db.prepare('SELECT * FROM nominees WHERE id=?').get(x.lastInsertRowid));});
app.get('/api/admin/results',auth,admin,(_,res)=>res.json(db.prepare('SELECT e.title event,c.name category,n.name nominee,n.vote_count FROM nominees n JOIN categories c ON n.category_id=c.id JOIN events e ON c.event_id=e.id ORDER BY e.title,c.name,n.vote_count DESC').all()));

// Payment flow: mock is for local testing only. Real money requires a verified gateway webhook.
app.post('/api/payments/initialize',auth,(req,res)=>{
  const p=z.object({nominee_id:z.number().int().positive(),quantity:z.number().int().min(1).max(10000),phone:z.string().min(9).max(20)}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Enter a nominee, vote quantity and valid phone number.'});
  const nominee=db.prepare('SELECT n.id,c.event_id,e.vote_price,e.currency,e.status FROM nominees n JOIN categories c ON n.category_id=c.id JOIN events e ON c.event_id=e.id WHERE n.id=?').get(p.data.nominee_id);
  if(!nominee||nominee.status!=='published')return res.status(404).json({error:'This nominee is not currently accepting votes.'});
  const reference=`CV-${randomUUID()}`;const amount=nominee.vote_price*p.data.quantity;
  db.prepare('INSERT INTO payments(user_id,reference,provider,amount,currency,metadata) VALUES(?,?,?,?,?,?)').run(req.user.id,reference,process.env.PAYMENT_PROVIDER||'mock',amount,nominee.currency,JSON.stringify({nominee_id:p.data.nominee_id,quantity:p.data.quantity,phone:p.data.phone}));
  res.status(201).json({reference,amount,currency:nominee.currency,status:'pending',message:'Payment initialized. No money has been collected in demo mode.'});
});
app.post('/api/payments/mock-confirm/:reference',auth,(req,res)=>{
  if(process.env.NODE_ENV==='production'||process.env.PAYMENT_PROVIDER!=='mock')return res.status(404).json({error:'Not available.'});
  const pay=db.prepare('SELECT * FROM payments WHERE reference=? AND user_id=?').get(req.params.reference,req.user.id);if(!pay)return res.status(404).json({error:'Payment not found.'});if(pay.status==='paid')return res.json({status:'paid',message:'Already confirmed.'});
  const m=JSON.parse(pay.metadata);const confirm=db.transaction(()=>{db.prepare("UPDATE payments SET status='paid' WHERE id=? AND status='pending'").run(pay.id);const updated=db.prepare('SELECT status FROM payments WHERE id=?').get(pay.id);if(updated.status==='paid'&&!db.prepare('SELECT id FROM votes WHERE payment_id=?').get(pay.id)){db.prepare('INSERT INTO votes(payment_id,user_id,nominee_id,quantity) VALUES(?,?,?,?)').run(pay.id,pay.user_id,m.nominee_id,m.quantity);db.prepare('UPDATE nominees SET vote_count=vote_count+? WHERE id=?').run(m.quantity,m.nominee_id);}});confirm();res.json({status:'paid',message:'Demo payment confirmed and votes recorded.'});
});
app.get('/api/votes/mine',auth,(req,res)=>res.json(db.prepare('SELECT v.quantity,v.created_at,n.name nominee,p.reference,p.status payment_status FROM votes v JOIN nominees n ON v.nominee_id=n.id JOIN payments p ON v.payment_id=p.id WHERE v.user_id=? ORDER BY v.created_at DESC').all(req.user.id)));
app.get('*',(req,res)=>res.sendFile(process.cwd()+'/public/index.html'));
app.listen(PORT,()=>console.log(`CrownVotes running at http://localhost:${PORT}`));
