import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
const db = new Database('crownvotes.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'voter', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, title TEXT NOT NULL, slug TEXT UNIQUE NOT NULL, description TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'draft', starts_at TEXT, ends_at TEXT, vote_price INTEGER NOT NULL DEFAULT 1, currency TEXT NOT NULL DEFAULT 'GHS', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL REFERENCES events(id), name TEXT NOT NULL, description TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS nominees(id INTEGER PRIMARY KEY, category_id INTEGER NOT NULL REFERENCES categories(id), name TEXT NOT NULL, bio TEXT DEFAULT '', image_url TEXT DEFAULT '', vote_count INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id), reference TEXT UNIQUE NOT NULL, provider TEXT NOT NULL, amount INTEGER NOT NULL, currency TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', metadata TEXT DEFAULT '{}', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS votes(id INTEGER PRIMARY KEY, payment_id INTEGER REFERENCES payments(id), user_id INTEGER REFERENCES users(id), nominee_id INTEGER NOT NULL REFERENCES nominees(id), quantity INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
const adminEmail = process.env.ADMIN_EMAIL || 'admin@crownvotes.com';
const adminPassword = process.env.ADMIN_PASSWORD || 'ChangeThisPassword123!';
if (!db.prepare('SELECT id FROM users WHERE email=?').get(adminEmail)) {
  db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run('CrownVotes Admin', adminEmail, bcrypt.hashSync(adminPassword, 12), 'admin');
}
export default db;
